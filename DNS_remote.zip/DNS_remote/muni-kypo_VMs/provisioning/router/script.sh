#!/bin/bash

while true
do 
	sudo rndc flush
	sleep 5
done